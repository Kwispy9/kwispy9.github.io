import os
import socket
import threading
import pickle
import struct
import sys

os.system("cls" if os.name == "nt" else "clear")

clients = []
serverPort = 5555

helpList = [
    "CLEAR         Clear the canvas for all users.",
    "STOP          Stop the server."
]

server = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
server.bind(("", serverPort))
server.listen()

# Thread-safe print above input
print_lock = threading.Lock()
current_input = ""

def print_above_input(msg):
    with print_lock:
        # Move to start of line and clear current line
        sys.stdout.write('\r')
        sys.stdout.write(' ' * (len(current_input) + len("inputCommand> ")))
        sys.stdout.write('\r')
        print(msg)
        # Reprint input only if the user is typing
        if current_input:
            sys.stdout.write(f"inputCommand> {current_input}")
            sys.stdout.flush()

print_above_input(f"Server started with port {serverPort}\nWaiting for clients...")

def broadcast(msg, exclude=None):
    data = pickle.dumps(msg)
    data = struct.pack(">I", len(data)) + data
    for client in clients:
        if client != exclude:
            try:
                client.sendall(data)
            except:
                clients.remove(client)

def handle_client(client):
    while True:
        try:
            buffer = b""
            while True:
                packet = client.recv(4096)
                if not packet:
                    raise ConnectionError
                buffer += packet
                while True:
                    if len(buffer) < 4:
                        break
                    msg_len = struct.unpack(">I", buffer[:4])[0]
                    if len(buffer) < 4 + msg_len:
                        break
                    msg_data = buffer[4:4+msg_len]
                    buffer = buffer[4+msg_len:]
                    msg = pickle.loads(msg_data)
                    broadcast(msg, exclude=client)
        except:
            if client in clients:
                clients.remove(client)
            client.close()
            break

def accept_clients():
    while True:
        client, addr = server.accept()
        clients.append(client)
        threading.Thread(target=handle_client, args=(client,), daemon=True).start()
        print_above_input(f"Client connected: {addr}")

threading.Thread(target=accept_clients, daemon=True).start()

# Command loop
print_above_input("\nType 'help' for a list of commands.")
while True:
    try:
        # input() displays the prompt normally
        current_input = input("").strip()
    except EOFError as err:
        print(f"EOFError {err}")
        break

    cmd = current_input.lower()

    if cmd == "help":
        print_above_input("")  # empty line
        for helpItems in helpList:
            print_above_input(helpItems)
        print_above_input("")
    elif cmd == "clear":
        print_above_input("Clearing canvas for all clients...")
        broadcast("CLEAR_ALL")
    elif cmd == "stop":
        print_above_input("Stopping server...")
        exit()