import os
import socket
import threading
import pickle
import struct
import sys
import subprocess
from datetime import datetime

try:
    import psutil
except ImportError:
    print("Installing dependencies...")
    subprocess.run([sys.executable, "-m", "pip", "install", "psutil"])
    print("\nDone. Please restart the program.")
    exit()

os.system("cls" if os.name == "nt" else "clear")

clients = []
hostname = socket.gethostname()

#------default_port = 5555-------------------------------------#
server_port = 5555 # DO NOT EDIT ANYTHING OUTSIDE OF THIS FRAME
#--------------------------------------------------------------#

helpList = [
    "CLEARCANVAS   Clear the canvas for all users.",
    "CLEAR         Clear the terminal.",
    "CLS           Clear the terminal.",
    "IP            Show the server IP and Port.",
    "STOP          Stop the server."
]

print("Creating server socket...")
server = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
print(f"Binding server to port {server_port}...")
server.bind(("", server_port))
print("Done.")
server.listen()

# Thread-safe print above input
print_lock = threading.Lock()
current_input = ""


def print_above_input(msg):
    with print_lock:
        sys.stdout.write('\r')
        sys.stdout.write(' ' * (len(current_input) + len("inputCommand> ")))
        sys.stdout.write('\r')
        print(msg)
        if current_input:
            sys.stdout.write(f"")
            sys.stdout.flush()


# ---------- Get Wi-Fi IP ----------
server_ip = None
for interface, addrs in psutil.net_if_addrs().items():
    if "virtual" in interface.lower():
        continue
    if not any(x in interface.lower() for x in ["wi-fi", "wireless", "wlan", "wifi"]):
        continue
    print("\nIP list:")
    for ip in socket.gethostbyname_ex(hostname)[2]:
        print(f"[Detected IP] {ip}")
    for addr in addrs:
        if addr.family == socket.AF_INET and not addr.address.startswith("127."):
            server_ip = addr.address
            #print(f"Detected Wi-Fi IP: {server_ip}")
            print(f"\nServer started at {server_ip} with port {server_port}")
            print("If this IP doesn't work, try the ones listed above, or find your router's IP and use that.\n")

# ---------- Broadcasting ----------
def broadcast(msg, exclude=None):
    print(f"[{datetime.now().strftime('%H:%M:%S')}] Broadcasting message to clients...")
    data = pickle.dumps(msg)
    data = struct.pack(">I", len(data)) + data
    for client in clients:
        if client != exclude:
            try:
                client.sendall(data)
            except Exception as e:
                print(f"Error sending message to client: {e}")
                if client in clients:
                    clients.remove(client)
    print(f"[{datetime.now().strftime('%H:%M:%S')}] Done.")

# ---------- Client Handling ----------
def handle_client(client):
    addr = client.getpeername()
    print(f"[{datetime.now().strftime('%H:%M:%S')}] Starting thread for client from {addr}...")
    buffer = b""
    while True:
        try:
            packet = client.recv(4096)
            if not packet:
                raise ConnectionError("Client disconnected")
            buffer += packet

            while len(buffer) >= 4:
                msg_len = struct.unpack(">I", buffer[:4])[0]
                if len(buffer) < 4 + msg_len:
                    break  # wait for more data
                msg_data = buffer[4:4+msg_len]
                buffer = buffer[4+msg_len:]

                msg = pickle.loads(msg_data)
                # check for log type
                if isinstance(msg, dict) and msg.get("type") == "log":
                    print(f"\n[{datetime.now().strftime('%H:%M:%S')}] [MESSAGE FROM CLIENT] {msg.get('message')} [{addr}]")
                else:
                    broadcast(msg, exclude=client)
                print(f"[{datetime.now().strftime('%H:%M:%S')}] Received message from {addr}: {msg}")
                
        except Exception as e:
            print(f"[{datetime.now().strftime('%H:%M:%S')}] Client disconnected from {addr}; {e} (Total clients: {len(clients)})")
            if client in clients:
                clients.remove(client)
            client.close()
            break


def accept_clients():
    while True:
        client, addr = server.accept()
        clients.append(client)
        print(f"[{datetime.now().strftime('%H:%M:%S')}] Client connecting...")
        threading.Thread(target=handle_client, args=(client,), daemon=True).start()
        print(f"[{datetime.now().strftime('%H:%M:%S')}] Client connected from {addr}\n(Total clients: {len(clients)})")


threading.Thread(target=accept_clients, daemon=True).start()

# ---------- Command Loop ----------
print_above_input("Type 'help' for a list of commands.")
while True:
    try:
        current_input = input("").strip()
    except EOFError as err:
        print(f"EOFError: {err}")
        break

    cmd = current_input.lower()

    if cmd == "help":
        print_above_input("")
        for helpItems in helpList:
            print_above_input(helpItems)
        print_above_input("")
    elif cmd == "clearcanvas":
        print_above_input("Are you sure you want to clear the canvas? This will do so for all users. [Y/N]")
        confirm = input().lower().strip()
        if confirm == "y":
            print_above_input(f"[{datetime.now().strftime('%H:%M:%S')}] Clearing canvas for all clients...")
            broadcast("CLEAR_ALL")
            print_above_input("Done.")
        else:
            pass
    elif cmd in ("cls", "clear"):
        os.system("cls" if os.name == "nt" else "clear")
    elif cmd == "ip":
        print("\nIP list:")
        for ip in socket.gethostbyname_ex(hostname)[2]:
            print(f"[Detected IP] {ip}")
        print(f"\nServer started at {server_ip} with port {server_port}")
        print("If this IP doesn't work, try the ones listed above, or find your router's IP and use that.\n")
    elif cmd == "stop":
        print_above_input("Are you sure you want to stop the server? [Y/N]")
        confirm = input().lower().strip()
        if confirm == "y":
            print(f"[{datetime.now().strftime('%H:%M:%S')}] Stopping server...")
            for client in clients:
                try:
                    client.shutdown(socket.SHUT_RDWR)
                    client.close()
                except:
                    pass
            exit()
        else:
            pass